'use strict';
require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const helmet     = require('helmet');
const fetch      = require('node-fetch');
const path       = require('path');
const fs         = require('fs');
const crypto     = require('crypto');
const initSqlJs  = require('sql.js');
const app  = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'mexieon.db');
let db;

async function initDatabase() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    db = new SQL.Database(fs.readFileSync(DB_PATH));
    console.log('[DB] Loaded existing database');
  } else {
    db = new SQL.Database();
    console.log('[DB] Created new database');
  }
  db.run(`CREATE TABLE IF NOT EXISTS managers (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL, role TEXT NOT NULL, entity TEXT NOT NULL, entity_color TEXT NOT NULL, avatar TEXT NOT NULL, pin_hash TEXT NOT NULL, tier TEXT NOT NULL DEFAULT 'operational', agents TEXT NOT NULL DEFAULT '[]', created_at INTEGER DEFAULT (strftime('%s','now')))`);
  db.run(`CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, manager_id INTEGER NOT NULL, login_at INTEGER NOT NULL, last_seen INTEGER NOT NULL, logout_at INTEGER, current_panel TEXT DEFAULT 'dashboard', actions_today INTEGER DEFAULT 0)`);
  db.run(`CREATE TABLE IF NOT EXISTS activity_log (id INTEGER PRIMARY KEY AUTOINCREMENT, manager_id INTEGER NOT NULL, session_id TEXT NOT NULL, action TEXT NOT NULL, detail TEXT, panel TEXT, ts INTEGER DEFAULT (strftime('%s','now')))`);
  db.run(`CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, channel TEXT NOT NULL, sender_id INTEGER NOT NULL, sender_name TEXT NOT NULL, message TEXT NOT NULL, ts INTEGER DEFAULT (strftime('%s','now')))`);
  db.run(`CREATE TABLE IF NOT EXISTS escalations (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT, customer_email TEXT, order_id TEXT, lifetime_value REAL DEFAULT 0, wallet_balance REAL DEFAULT 0, issue_type TEXT NOT NULL, trigger_reason TEXT NOT NULL, nova_transcript TEXT, nova_briefing TEXT NOT NULL, nova_recommendation TEXT, status TEXT DEFAULT 'open', assigned_to INTEGER, assigned_name TEXT, resolution TEXT, goodwill_credit REAL DEFAULT 0, created_at INTEGER DEFAULT (strftime('%s','now')), resolved_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS escalation_replies (id INTEGER PRIMARY KEY AUTOINCREMENT, escalation_id INTEGER NOT NULL, sender_id INTEGER NOT NULL, sender_name TEXT NOT NULL, message TEXT NOT NULL, is_to_customer INTEGER DEFAULT 0, nova_suggested TEXT, ts INTEGER DEFAULT (strftime('%s','now')))`);
  const count = db.exec('SELECT COUNT(*) as c FROM managers');
  if (!count.length || count[0].values[0][0] === 0) seedManagers();
  saveDatabase();
  console.log('[DB] Tables ready');
}

function saveDatabase() {
  if (!db) return;
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}
setInterval(saveDatabase, 30000);

function hashPin(pin) {
  return crypto.createHash('sha256').update(pin + (process.env.PIN_SALT || 'mexieon_v9_salt')).digest('hex');
}

function seedManagers() {
  const managers = [
    { u:'ceo',       dn:'Chief Executive Officer',    role:'CEO / President',       entity:'Holdings Corporation', ec:'#a78bfa', av:'👑', pin:'1111', tier:'executive',    ag:'["GUARDIAN","SENTINEL","ORACLE","NEXUS"]' },
    { u:'director1', dn:'Board Director — Finance',   role:'Board Director',         entity:'Holdings Corporation', ec:'#a78bfa', av:'🏛️', pin:'2222', tier:'executive',    ag:'["ORACLE","GUARDIAN"]' },
    { u:'director2', dn:'Board Director — Operations',role:'Board Director',         entity:'Holdings Corporation', ec:'#a78bfa', av:'📊', pin:'3333', tier:'executive',    ag:'["SENTINEL","ORACLE"]' },
    { u:'gm',        dn:'President / General Manager',role:'President / GM',         entity:'Mexieon Corporation',  ec:'#fb923c', av:'🏢', pin:'4444', tier:'executive',    ag:'["NOVA","LUMEN","FLUX","SIGNAL","CATALYST","PULSE","BEACON"]' },
    { u:'vpcommerce',dn:'VP Commerce',                role:'VP Commerce',             entity:'Mexieon Corporation',  ec:'#fb923c', av:'🛒', pin:'5555', tier:'operational', ag:'["CATALYST","PULSE","HUNTER","LUMEN"]' },
    { u:'cto',       dn:'CTO / Logistics Director',   role:'CTO / Director',         entity:'R&D Logistics',        ec:'#34d399', av:'⚙️', pin:'6666', tier:'executive',    ag:'["COMPASS","RELAY","STOCK","HUNTER"]' },
    { u:'logistics', dn:'Logistics Manager',          role:'Logistics Manager',       entity:'R&D Logistics',        ec:'#34d399', av:'📦', pin:'7777', tier:'operational', ag:'["RELAY","STOCK","COMPASS"]' },
    { u:'property',  dn:'Property Manager',           role:'Property Manager',        entity:'Real Estate',          ec:'#fbbf24', av:'🏗️', pin:'8888', tier:'operational', ag:'["ANCHOR"]' },
    { u:'cx',        dn:'Customer Experience Manager',role:'CX Manager',              entity:'Mexieon Corporation',  ec:'#fb923c', av:'💬', pin:'9999', tier:'operational', ag:'["NOVA","CATALYST"]' },
  ];
  const stmt = db.prepare('INSERT INTO managers (username,display_name,role,entity,entity_color,avatar,pin_hash,tier,agents) VALUES (?,?,?,?,?,?,?,?,?)');
  managers.forEach(m => stmt.run([m.u, m.dn, m.role, m.entity, m.ec, m.av, hashPin(m.pin), m.tier, m.ag]));
  stmt.free();
  db.run(`INSERT INTO chat_messages (channel,sender_id,sender_name,message) VALUES ('all',0,'NEXUS','Mexieon V9 Manager Hub is online. All 9 manager accounts are active. Welcome to the team.')`);
  saveDatabase();
  console.log('[DB] 9 managers seeded. Default PINs: CEO=1111 ... CX=9999');
}

function generateSessionId() { return crypto.randomBytes(24).toString('hex'); }

function getSession(sessionId) {
  if (!db || !sessionId) return null;
  try {
    const r = db.exec(`SELECT s.*,m.username,m.display_name,m.role,m.entity,m.entity_color,m.avatar,m.tier,m.agents,m.id as manager_id FROM sessions s JOIN managers m ON s.manager_id=m.id WHERE s.id=? AND s.logout_at IS NULL`, [sessionId]);
    if (!r.length || !r[0].values.length) return null;
    const cols = r[0].columns; const vals = r[0].values[0];
    const session = {}; cols.forEach((c,i) => session[c]=vals[i]);
    if (Date.now()/1000 - session.login_at > 14400) {
      db.run('UPDATE sessions SET logout_at=? WHERE id=?', [Math.floor(Date.now()/1000), sessionId]);
      saveDatabase(); return null;
    }
    return session;
  } catch(e) { return null; }
}

function requireAuth(req, res, next) {
  const session = getSession(req.headers['x-session-id']);
  if (!session) return res.status(401).json({ error:'Not authenticated' });
  req.session = session;
  db.run('UPDATE sessions SET last_seen=? WHERE id=?', [Math.floor(Date.now()/1000), session.id]);
  next();
}

function createEscalation(d) {
  if (!db) return;
  try {
    db.run(`INSERT INTO escalations (customer_name,customer_email,order_id,issue_type,trigger_reason,nova_transcript,nova_briefing,nova_recommendation) VALUES (?,?,?,?,?,?,?,?)`,
      [d.customerName,d.customerEmail||'',d.orderId||'',d.issueType,d.trigger||'NOVA escalation',d.novaTranscript||'',d.novaBriefing,d.novaRecommendation||'']);
    db.run(`INSERT INTO chat_messages (channel,sender_id,sender_name,message) VALUES ('escalations',0,'NOVA',?)`,
      [`🚨 New escalation: ${d.issueType} — Customer: ${d.customerName}. Trigger: ${d.trigger}`]);
    saveDatabase();
  } catch(e) { console.error('[ESC]',e.message); }
}

app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc:["'self'"], scriptSrc:["'self'","'unsafe-inline'",'fonts.googleapis.com','cdnjs.cloudflare.com'], styleSrc:["'self'","'unsafe-inline'",'fonts.googleapis.com','fonts.gstatic.com'], fontSrc:["'self'",'fonts.gstatic.com'], connectSrc:["'self'"], imgSrc:["'self'",'data:'] } } }));
app.use(cors({ origin:['http://localhost:3000','http://127.0.0.1:3000'], methods:['GET','POST','PATCH'], allowedHeaders:['Content-Type','X-Session-Id'] }));
app.use(express.json({ limit:'32kb' }));
const apiLimiter  = rateLimit({ windowMs:60000, max:120 });
const agentLimiter= rateLimit({ windowMs:60000, max:30 });
const authLimiter = rateLimit({ windowMs:60000, max:10, message:{error:'Too many login attempts'} });
app.use('/api/',      apiLimiter);
app.use('/api/agent', agentLimiter);
app.use('/api/auth',  authLimiter);

function sanitiseText(s,n=2000){ if(typeof s!=='string')return ''; return s.slice(0,n).replace(/ignore (all |previous |prior |above |any )(instructions?|prompts?|rules?|directives?)/gi,'[filtered]').replace(/you are now|pretend (to be|you are)|act as|disregard|forget (everything|all)/gi,'[filtered]').replace(/system prompt|jailbreak|DAN mode|developer mode/gi,'[filtered]').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g,'').trim(); }

const MODEL_FAST='claude-haiku-4-5-20251001';
const MODEL_FULL='claude-sonnet-4-20250514';
const AGENT_MODELS={SENTINEL:MODEL_FULL,ORACLE:MODEL_FULL,COMPASS:MODEL_FULL,PULSE:MODEL_FULL,CATALYST:MODEL_FULL,BEACON:MODEL_FULL,HUNTER:MODEL_FULL,NEXUS:MODEL_FULL,GUARDIAN:MODEL_FAST,RELAY:MODEL_FAST,STOCK:MODEL_FAST,LUMEN:MODEL_FAST,FLUX:MODEL_FAST,SIGNAL:MODEL_FAST,NOVA:MODEL_FAST,ANCHOR:MODEL_FAST};
function getModel(n){ return AGENT_MODELS[n?.toUpperCase()]||MODEL_FAST; }

const eventSubscribers={}, eventLog=[];
function busEmit(event,data,src){ const e={event,data,sourceAgent:src,ts:Date.now()}; eventLog.push(e); if(eventLog.length>200)eventLog.shift(); (eventSubscribers[event]||[]).forEach(fn=>{try{fn(e);}catch(e){}}) ; }
function busSubscribe(ev,fn){ if(!eventSubscribers[ev])eventSubscribers[ev]=[]; eventSubscribers[ev].push(fn); }
busSubscribe('fraud:flagged',({data})=>{ busEmit('oracle:recheck_margin',{},'SYSTEM'); busEmit('guardian:check_region',{country:data.country||'unknown'},'SYSTEM'); if(data.value>75) createEscalation({customerName:data.customerName||'Unknown',issueType:'Fraud Hold — High Value',trigger:'SENTINEL auto-escalation',novaBriefing:`SENTINEL flagged order. Value: $${data.value}. Billing/ship mismatch. Customer may contest.`,novaRecommendation:'Verify identity by phone. Do not release without CX Manager approval.'}); });
busSubscribe('stock:critical',({data})=>busEmit('relay:switch_supplier',{sku:data.sku},'SYSTEM'));
busSubscribe('hunter:opportunity_found',()=>{ busEmit('oracle:pre_check_margin',{},'SYSTEM'); busEmit('compass:pre_vet_seller',{},'SYSTEM'); });

// ── AUTH ──
app.get('/api/managers',(req,res)=>{
  if(!db)return res.json({managers:[]});
  try{
    const r=db.exec('SELECT id,username,display_name,role,entity,entity_color,avatar FROM managers ORDER BY id');
    if(!r.length)return res.json({managers:[]});
    const managers=r[0].values.map(row=>{const m={};r[0].columns.forEach((c,i)=>m[c]=row[i]);return m;});
    res.json({managers});
  }catch(e){res.json({managers:[]});}
});

app.post('/api/auth/login',(req,res)=>{
  const{username,pin}=req.body;
  if(!username||!pin)return res.status(400).json({error:'Username and PIN required'});
  if(!db)return res.status(503).json({error:'Database not ready'});
  try{
    const r=db.exec('SELECT * FROM managers WHERE username=? AND pin_hash=?',[username.toLowerCase(),hashPin(String(pin))]);
    if(!r.length||!r[0].values.length)return res.status(401).json({error:'Invalid username or PIN'});
    const cols=r[0].columns; const manager={};
    cols.forEach((c,i)=>manager[c]=r[0].values[0][i]); delete manager.pin_hash;
    db.run('UPDATE sessions SET logout_at=? WHERE manager_id=? AND logout_at IS NULL',[Math.floor(Date.now()/1000),manager.id]);
    const sessionId=generateSessionId(); const now=Math.floor(Date.now()/1000);
    db.run('INSERT INTO sessions (id,manager_id,login_at,last_seen) VALUES (?,?,?,?)',[sessionId,manager.id,now,now]);
    db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail,panel) VALUES (?,?,'login',?,'dashboard')`,[manager.id,sessionId,`${manager.display_name} logged in`]);
    db.run(`INSERT INTO chat_messages (channel,sender_id,sender_name,message) VALUES ('all',0,'SYSTEM',?)`,[`${manager.avatar} ${manager.display_name} is now online`]);
    saveDatabase();
    res.json({sessionId,manager:{...manager,agents:JSON.parse(manager.agents||'[]')}});
  }catch(e){console.error('[AUTH]',e.message);res.status(500).json({error:'Login failed'});}
});

app.get('/api/auth/verify',(req,res)=>{
  const session=getSession(req.headers['x-session-id']);
  if(!session)return res.status(401).json({valid:false});
  res.json({valid:true,manager:{id:session.manager_id,username:session.username,display_name:session.display_name,role:session.role,entity:session.entity,entity_color:session.entity_color,avatar:session.avatar,tier:session.tier,agents:JSON.parse(session.agents||'[]'),session_id:session.id}});
});

app.post('/api/auth/logout',requireAuth,(req,res)=>{
  const now=Math.floor(Date.now()/1000);
  db.run('UPDATE sessions SET logout_at=? WHERE id=?',[now,req.session.id]);
  db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail) VALUES (?,?,'logout',?)`,[req.session.manager_id,req.session.id,`${req.session.display_name} logged out`]);
  db.run(`INSERT INTO chat_messages (channel,sender_id,sender_name,message) VALUES ('all',0,'SYSTEM',?)`,[`${req.session.avatar} ${req.session.display_name} has gone offline`]);
  saveDatabase(); res.json({ok:true});
});

// ── PRESENCE ──
app.post('/api/presence/update',requireAuth,(req,res)=>{
  const{panel,action,detail}=req.body; const now=Math.floor(Date.now()/1000);
  db.run('UPDATE sessions SET last_seen=?,current_panel=? WHERE id=?',[now,panel||'dashboard',req.session.id]);
  if(action){
    db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail,panel) VALUES (?,?,?,?,?)`,[req.session.manager_id,req.session.id,action,detail||'',panel||'']);
    db.run('UPDATE sessions SET actions_today=actions_today+1 WHERE id=?',[req.session.id]);
  }
  res.json({ok:true});
});

app.get('/api/presence/all',requireAuth,(req,res)=>{
  if(!db)return res.json({presence:[]});
  try{
    const now=Math.floor(Date.now()/1000);
    const r=db.exec(`SELECT m.id,m.username,m.display_name,m.role,m.entity,m.entity_color,m.avatar,m.tier,s.id as session_id,s.login_at,s.last_seen,s.current_panel,s.actions_today,CASE WHEN s.id IS NULL THEN 'offline' WHEN (?-s.last_seen)>900 THEN 'idle' ELSE 'online' END as status,(?-s.login_at) as session_duration FROM managers m LEFT JOIN sessions s ON m.id=s.manager_id AND s.logout_at IS NULL ORDER BY m.id`,[now,now]);
    if(!r.length)return res.json({presence:[]});
    const presence=r[0].values.map(row=>{const p={};r[0].columns.forEach((c,i)=>p[c]=row[i]);return p;});
    res.json({presence});
  }catch(e){res.json({presence:[]});}
});

// ── CHAT ──
const CHANNELS={all:{name:'All Managers',icon:'🌐'},holdings:{name:'Holdings Corp',icon:'🏛️'},corporation:{name:'Corporation',icon:'🛒'},rnd:{name:'R&D Logistics',icon:'⚙️'},realestate:{name:'Real Estate',icon:'🏗️'},escalations:{name:'Escalations',icon:'🚨'}};
app.get('/api/chat/channels',requireAuth,(req,res)=>res.json({channels:CHANNELS}));

app.get('/api/chat/messages/:channel',requireAuth,(req,res)=>{
  const ch=req.params.channel;
  if(!CHANNELS[ch]&&!ch.startsWith('dm_'))return res.status(400).json({error:'Invalid channel'});
  try{
    const r=db.exec('SELECT id,channel,sender_id,sender_name,message,ts FROM chat_messages WHERE channel=? ORDER BY ts DESC LIMIT 60',[ch]);
    const messages=r.length?r[0].values.map(row=>({id:row[0],channel:row[1],sender_id:row[2],sender_name:row[3],message:row[4],ts:row[5]})).reverse():[];
    res.json({messages});
  }catch(e){res.json({messages:[]});}
});

app.post('/api/chat/send',requireAuth,(req,res)=>{
  const{channel,message}=req.body; const cleanMsg=sanitiseText(message,1000);
  if(!cleanMsg)return res.status(400).json({error:'Empty message'});
  if(!CHANNELS[channel]&&!channel.startsWith('dm_'))return res.status(400).json({error:'Invalid channel'});
  try{
    db.run('INSERT INTO chat_messages (channel,sender_id,sender_name,message) VALUES (?,?,?,?)',[channel,req.session.manager_id,req.session.display_name,cleanMsg]);
    db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail,panel) VALUES (?,?,'chat',?,?)`,[req.session.manager_id,req.session.id,`Message in ${channel}`,channel]);
    saveDatabase(); res.json({ok:true});
  }catch(e){res.status(500).json({error:'Send failed'});}
});

app.get('/api/chat/unread',requireAuth,(req,res)=>{
  try{
    const r=db.exec(`SELECT channel,COUNT(*) as count FROM chat_messages WHERE ts>(SELECT COALESCE(MAX(ts),0) FROM chat_messages WHERE sender_id=?) AND sender_id!=? GROUP BY channel`,[req.session.manager_id,req.session.manager_id]);
    const unread={};
    if(r.length)r[0].values.forEach(row=>{unread[row[0]]=row[1];});
    res.json({unread});
  }catch(e){res.json({unread:{}});}
});

// ── ESCALATIONS ──
app.get('/api/escalations',requireAuth,(req,res)=>{
  try{
    const r=db.exec('SELECT * FROM escalations ORDER BY created_at DESC LIMIT 100');
    const escalations=r.length?r[0].values.map(row=>{const e={};r[0].columns.forEach((c,i)=>e[c]=row[i]);return e;}):[];
    res.json({escalations});
  }catch(e){res.json({escalations:[]});}
});

app.post('/api/escalations/create',requireAuth,(req,res)=>{
  const{customerName,customerEmail,orderId,issueType,trigger,novaTranscript,novaBriefing,novaRecommendation}=req.body;
  if(!novaBriefing||!issueType)return res.status(400).json({error:'briefing and issueType required'});
  createEscalation({customerName:sanitiseText(customerName||'Unknown',200),customerEmail:sanitiseText(customerEmail||'',200),orderId:sanitiseText(orderId||'',100),issueType:sanitiseText(issueType,200),trigger:sanitiseText(trigger||'Manual',200),novaTranscript:sanitiseText(novaTranscript||'',5000),novaBriefing:sanitiseText(novaBriefing,3000),novaRecommendation:sanitiseText(novaRecommendation||'',1000)});
  db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail,panel) VALUES (?,?,'escalation_created',?,'escalations')`,[req.session.manager_id,req.session.id,`Escalation: ${issueType}`]);
  saveDatabase(); res.json({ok:true});
});

app.post('/api/escalations/:id/assign',requireAuth,(req,res)=>{
  try{
    db.run(`UPDATE escalations SET assigned_to=?,assigned_name=?,status='in_progress' WHERE id=?`,[req.session.manager_id,req.session.display_name,req.params.id]);
    db.run(`INSERT INTO chat_messages (channel,sender_id,sender_name,message) VALUES ('escalations',?,?,?)`,[req.session.manager_id,req.session.display_name,`${req.session.display_name} has taken escalation #${req.params.id}`]);
    saveDatabase(); res.json({ok:true});
  }catch(e){res.status(500).json({error:'Assign failed'});}
});

app.post('/api/escalations/:id/reply',requireAuth,(req,res)=>{
  const{message,isToCustomer,novaSuggested}=req.body; const cleanMsg=sanitiseText(message,2000);
  if(!cleanMsg)return res.status(400).json({error:'Empty message'});
  try{
    db.run('INSERT INTO escalation_replies (escalation_id,sender_id,sender_name,message,is_to_customer,nova_suggested) VALUES (?,?,?,?,?,?)',[req.params.id,req.session.manager_id,req.session.display_name,cleanMsg,isToCustomer?1:0,novaSuggested||'']);
    db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail,panel) VALUES (?,?,'escalation_reply',?,'escalations')`,[req.session.manager_id,req.session.id,`Reply to #${req.params.id}${isToCustomer?' (to customer)':''}`]);
    saveDatabase(); res.json({ok:true});
  }catch(e){res.status(500).json({error:'Reply failed'});}
});

app.post('/api/escalations/:id/resolve',requireAuth,(req,res)=>{
  const{resolution,goodwillCredit}=req.body; const now=Math.floor(Date.now()/1000);
  try{
    db.run(`UPDATE escalations SET status='resolved',resolution=?,goodwill_credit=?,resolved_at=?,assigned_to=?,assigned_name=? WHERE id=?`,[sanitiseText(resolution||'',2000),goodwillCredit||0,now,req.session.manager_id,req.session.display_name,req.params.id]);
    db.run(`INSERT INTO chat_messages (channel,sender_id,sender_name,message) VALUES ('escalations',?,?,?)`,[req.session.manager_id,req.session.display_name,`✓ Escalation #${req.params.id} resolved by ${req.session.display_name}${goodwillCredit?` — $${goodwillCredit} goodwill credit issued to WALLET`:''}`]);
    db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail,panel) VALUES (?,?,'escalation_resolved',?,'escalations')`,[req.session.manager_id,req.session.id,`Resolved #${req.params.id}`]);
    saveDatabase(); res.json({ok:true});
  }catch(e){res.status(500).json({error:'Resolve failed'});}
});

app.get('/api/escalations/:id/replies',requireAuth,(req,res)=>{
  try{
    const r=db.exec('SELECT * FROM escalation_replies WHERE escalation_id=? ORDER BY ts ASC',[req.params.id]);
    const replies=r.length?r[0].values.map(row=>{const rp={};r[0].columns.forEach((c,i)=>rp[c]=row[i]);return rp;}):[];
    res.json({replies});
  }catch(e){res.json({replies:[]});}
});

app.post('/api/nova/escalate',requireAuth,(req,res)=>{
  const{customerName,customerEmail,orderId,issueType,transcript,trigger,lifetimeValue,walletBalance}=req.body;
  const briefing=`NOVA ESCALATION BRIEFING\n${'─'.repeat(40)}\nCustomer: ${customerName||'Unknown'}\nEmail: ${customerEmail||'Not provided'}\nOrder: ${orderId||'Not provided'}\nLifetime value: $${lifetimeValue||0}\nWallet balance: $${walletBalance||0}\n\nISSUE: ${issueType}\nTRIGGER: ${trigger||'NOVA could not resolve'}\n\nCONVERSATION:\n${transcript||'See NOVA logs'}\n\nNOVA RECOMMENDATION:\n${issueType?.toLowerCase().includes('legal')?'URGENT — forward to GM. No response without guidance.':(lifetimeValue>200?'High-value customer — priority resolution. Consider WALLET goodwill credit.':'Standard resolution. Verify order, offer replacement or refund per policy.')}`;
  createEscalation({customerName:sanitiseText(customerName||'Unknown',200),customerEmail:sanitiseText(customerEmail||'',200),orderId:sanitiseText(orderId||'',100),issueType:sanitiseText(issueType||'General',200),trigger:sanitiseText(trigger||'NOVA escalation',200),novaTranscript:sanitiseText(transcript||'',3000),novaBriefing:briefing,novaRecommendation:''});
  saveDatabase(); res.json({ok:true});
});

// ── ACTIVITY LOG ──
app.get('/api/activity',requireAuth,(req,res)=>{
  const mid=req.session.tier==='executive'&&req.query.manager_id?parseInt(req.query.manager_id):req.session.manager_id;
  try{
    const r=db.exec(`SELECT a.*,m.display_name,m.avatar,m.entity_color FROM activity_log a JOIN managers m ON a.manager_id=m.id WHERE a.manager_id=? AND a.ts>strftime('%s','now','-1 day') ORDER BY a.ts DESC LIMIT 200`,[mid]);
    const log=r.length?r[0].values.map(row=>{const l={};r[0].columns.forEach((c,i)=>l[c]=row[i]);return l;}):[];
    res.json({log});
  }catch(e){res.json({log:[]});}
});

// ── V8 RETAINED ENDPOINTS ──
app.get('/api/status',(req,res)=>res.json({server:'Mexieon V9',version:'9.0.0',keys:{anthropic:!!process.env.ANTHROPIC_API_KEY,shopify:!!process.env.SHOPIFY_API_KEY,sendgrid:!!process.env.SENDGRID_API_KEY,coinbase:!!process.env.COINBASE_COMMERCE_KEY,openexchange:!!process.env.OPENEXCHANGE_APP_ID,langfuse:!!process.env.LANGFUSE_PUBLIC_KEY},models:{fast:MODEL_FAST,full:MODEL_FULL},managerHubActive:true,dbActive:!!db,recentEvents:eventLog.slice(-10).map(e=>({event:e.event,agent:e.sourceAgent,ago:Math.round((Date.now()-e.ts)/1000)+'s ago'}))}));

app.post('/api/agent',agentLimiter,requireAuth,async(req,res)=>{
  const{agent,system,user,history}=req.body;
  if(!agent||!system||!user)return res.status(400).json({error:'Missing fields'});
  if(!process.env.ANTHROPIC_API_KEY)return res.status(503).json({error:'ANTHROPIC_API_KEY not set'});
  const cleanSystem=sanitiseText(system,4000); const cleanUser=sanitiseText(user,3000);
  const messages=[]; if(Array.isArray(history))history.slice(-10).forEach(m=>{if(m.role&&m.content)messages.push({role:m.role,content:sanitiseText(String(m.content),2000)});});
  messages.push({role:'user',content:cleanUser});
  const model=getModel(agent);
  try{
    const response=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'Content-Type':'application/json','x-api-key':process.env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},body:JSON.stringify({model,max_tokens:1200,system:cleanSystem,messages})});
    if(!response.ok)return res.status(response.status).json({error:`API error: ${response.status}`});
    const data=await response.json(); const reply=data.content?.map(b=>b.text||'').join('')||'';
    db.run(`INSERT INTO activity_log (manager_id,session_id,action,detail,panel) VALUES (?,?,'agent_query',?,?)`,[req.session.manager_id,req.session.id,`${agent} (${model.includes('haiku')?'fast':'full'})`,agent]);
    if(agent==='SENTINEL'&&reply.toLowerCase().includes('high'))busEmit('fraud:flagged',{value:0},'SENTINEL');
    if(agent==='STOCK'&&reply.toLowerCase().includes('critical'))busEmit('stock:critical',{sku:'unknown'},'STOCK');
    if(agent==='HUNTER')busEmit('hunter:opportunity_found',{seller:cleanUser.slice(0,100)},'HUNTER');
    saveDatabase(); res.json({reply,model,agent});
  }catch(e){console.error('[AGENT]',e.message);res.status(500).json({error:'Server error'});}
});

app.get('/api/events',requireAuth,(req,res)=>res.json({events:eventLog.slice(-50)}));
app.get('/api/fx-rates',async(req,res)=>{ if(!process.env.OPENEXCHANGE_APP_ID)return res.json({simulated:true,rates:{GBP:0.789,AUD:1.542,CAD:1.368,EUR:0.923,JPY:149.82}}); try{const r=await fetch(`https://openexchangerates.org/api/latest.json?app_id=${process.env.OPENEXCHANGE_APP_ID}`);const d=await r.json();res.json({live:true,rates:d.rates});}catch(e){res.status(500).json({error:'FX failed'});} });

app.use(express.static(path.join(__dirname,'public')));
app.get('*',(req,res)=>{const p=path.join(__dirname,'public','index.html');fs.existsSync(p)?res.sendFile(p):res.send('Place index.html in /public');});

initDatabase().then(()=>{
  app.listen(PORT,()=>{
    console.log(`\n╔══════════════════════════════════╗`);
    console.log(`║  MEXIEON V9  →  port ${PORT}      ║`);
    console.log(`║  http://localhost:${PORT}          ║`);
    console.log(`║  9 managers • SQLite • Chat      ║`);
    console.log(`║  Default PINs: CEO=1111→CX=9999  ║`);
    console.log(`╚══════════════════════════════════╝\n`);
  });
}).catch(err=>{console.error('DB init failed:',err);process.exit(1);});
module.exports=app;
